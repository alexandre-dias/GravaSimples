/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aprendizado.gravatxt;

import static com.aprendizado.gravatxt.Tela.criaTela;

/**
 *
 * @author alexandre.santos
 */
public class Main {
    public static void main(String[] args) {
        criaTela();
    }
}