/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aprendizado.gravatxt;

import java.awt.FileDialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 *
 * @author alexandre.santos
 */
public class Tela {
    
    static void criaTela() {
    JFrame tela;
    JButton btnGravar;
    JTextArea txtTexto;
    JLabel txtTitulo;
        
    tela = new JFrame("GravaTXT");
    
    btnGravar = new JButton("Gravar");
    btnGravar.setBounds(90, 320, 300, 100);
    
    txtTexto = new JTextArea();
    txtTexto.setBounds(90, 70, 300, 240);       
    
    txtTitulo = new JLabel("Escreva:");
    txtTitulo.setBounds(90, 10, 100, 100);
    
    tela.add(btnGravar);
    tela.add(txtTexto);
    tela.add(txtTitulo);
    
    tela.setLocationRelativeTo(null);
    tela.setResizable(false);
    tela.setLayout(null);
    tela.setSize(500, 500);
    tela.setVisible(true);
    tela.setDefaultCloseOperation(tela.EXIT_ON_CLOSE);
    
    btnGravar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String novoNome = "", gravando;    
                while(novoNome.isEmpty()) {
                    novoNome = JOptionPane.showInputDialog(null, "Dê um nome para o arquivo:");
                    }
                    FileWriter arq = new FileWriter("C:\\Users\\" + System.getProperty("user.name") + "\\Desktop\\" + novoNome + ".txt");
                    PrintWriter gravarArq = new PrintWriter(arq);
                    gravando = txtTexto.getText();
                    gravarArq.append(gravando);
                    JOptionPane.showMessageDialog(null, "O texto foi gravado.");
                    arq.close();                  
            } catch (IOException erro1) {
                JOptionPane.showMessageDialog(null, "Opa, algo deu errado!");
            } catch (Exception erro2) {
                JOptionPane.showMessageDialog(null, "Opa, você cancelou a operação!");
            }            
        }
    });
}
}
